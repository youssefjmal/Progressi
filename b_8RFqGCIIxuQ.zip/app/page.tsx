'use client';

import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { Button } from '@/components/ui/button';
import { Heart, Zap, Brain } from 'lucide-react';

export default function LandingPage() {
  const router = useRouter();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const checkAuth = async () => {
      const supabase = createClient();
      const {
        data: { session },
      } = await supabase.auth.getSession();

      if (session) {
        setIsAuthenticated(true);
        router.push('/dashboard');
      } else {
        setIsLoading(false);
      }
    };

    checkAuth();
  }, [router]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-background via-background to-background">
      {/* Header */}
      <header className="border-b border-border/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <h1 className="text-3xl font-bold">🍉 Coachini</h1>
        </div>
      </header>

      {/* Hero */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center space-y-8">
          <h1 className="text-5xl font-bold tracking-tight">
            Your AI Fitness Coach
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Track your nutrition, log your meals, and get personalized fitness coaching in English or French
          </p>

          <div className="flex gap-4 justify-center pt-8">
            <Button
              size="lg"
              onClick={() => router.push('/auth/signup')}
              className="px-8"
            >
              Get Started
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => router.push('/auth/login')}
              className="px-8"
            >
              Sign In
            </Button>
          </div>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-8 mt-20">
          <div className="p-6 rounded-lg border border-border bg-card">
            <Heart className="w-12 h-12 text-primary mb-4" />
            <h3 className="font-semibold text-lg mb-2">Track Nutrition</h3>
            <p className="text-muted-foreground">
              Log your meals and track calories, protein, carbs, and fats with our curated food database
            </p>
          </div>

          <div className="p-6 rounded-lg border border-border bg-card">
            <Zap className="w-12 h-12 text-primary mb-4" />
            <h3 className="font-semibold text-lg mb-2">Visualize Progress</h3>
            <p className="text-muted-foreground">
              Watch your daily calorie intake with our unique watermelon visualization
            </p>
          </div>

          <div className="p-6 rounded-lg border border-border bg-card">
            <Brain className="w-12 h-12 text-primary mb-4" />
            <h3 className="font-semibold text-lg mb-2">AI Coach</h3>
            <p className="text-muted-foreground">
              Get personalized fitness advice and coaching from your AI coach powered by Groq
            </p>
          </div>
        </div>

        {/* Bilingual Badge */}
        <div className="mt-20 p-8 rounded-lg border border-border bg-card text-center">
          <p className="text-muted-foreground mb-2">Available in English &amp; French</p>
          <p className="text-sm text-muted-foreground">
            Switch languages anytime from your profile settings
          </p>
        </div>
      </section>
    </main>
  );
}
