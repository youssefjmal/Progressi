'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { useLanguage } from '@/hooks/use-language';
import { t } from '@/lib/i18n';
import { Card } from '@/components/ui/card';
import { WatermelonChart } from '@/components/charts/watermelon-chart';

interface Profile {
  current_weight: number;
  activity_level: string;
}

export default function CaloriesPage() {
  const router = useRouter();
  const { language } = useLanguage();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [totalCalories, setTotalCalories] = useState(0);
  const [totalProtein, setTotalProtein] = useState(0);
  const [totalCarbs, setTotalCarbs] = useState(0);
  const [totalFat, setTotalFat] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const supabase = createClient();

  // Calculate daily calorie goal based on activity level
  const getCalorieGoal = (weight: number, activity: string): number => {
    const bmr = 10 * weight + 6.25 * 175 - 5 * 30 + 5; // Rough BMR calculation
    const multipliers: { [key: string]: number } = {
      sedentary: 1.2,
      light: 1.375,
      moderate: 1.55,
      active: 1.725,
      'very active': 1.9,
    };
    return Math.round(bmr * (multipliers[activity.toLowerCase()] || 1.55));
  };

  useEffect(() => {
    const loadData = async () => {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser();

        if (!user) {
          router.push('/auth/login');
          return;
        }

        // Load profile
        const { data: profileData } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();

        if (profileData) {
          setProfile(profileData);
        }

        // Load today's food logs
        const today = new Date().toISOString().split('T')[0];
        const { data: logsData } = await supabase
          .from('food_logs')
          .select('*')
          .eq('user_id', user.id)
          .gte('logged_at', `${today}T00:00:00`)
          .lte('logged_at', `${today}T23:59:59`);

        if (logsData) {
          setTotalCalories(
            logsData.reduce((sum, log) => sum + log.calories, 0)
          );
          setTotalProtein(
            logsData.reduce((sum, log) => sum + log.protein, 0)
          );
          setTotalCarbs(logsData.reduce((sum, log) => sum + log.carbs, 0));
          setTotalFat(logsData.reduce((sum, log) => sum + log.fat, 0));
        }
      } catch (err) {
        console.error('Error loading data:', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, [supabase, router]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  const calorieGoal = profile
    ? getCalorieGoal(
        profile.current_weight || 75,
        profile.activity_level || 'moderate'
      )
    : 2000;
  const remaining = Math.max(0, calorieGoal - totalCalories);

  return (
    <main className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">{t(language, 'calories.title')}</h1>

      {/* Watermelon Chart */}
      <Card className="p-8 mb-8 flex justify-center">
        <WatermelonChart consumed={totalCalories} goal={calorieGoal} />
      </Card>

      {/* Stats Grid */}
      <div className="grid md:grid-cols-2 gap-6 mb-8">
        <Card className="p-6">
          <p className="text-sm text-muted-foreground mb-2">
            {t(language, 'calories.remaining')}
          </p>
          <p className="text-3xl font-bold text-green-600">
            {Math.round(remaining)}
          </p>
          <p className="text-xs text-muted-foreground mt-2">
            Daily Goal: {calorieGoal}
          </p>
        </Card>

        <Card className="p-6">
          <p className="text-sm text-muted-foreground mb-2">
            {t(language, 'calories.todayCalories')}
          </p>
          <p className="text-3xl font-bold">
            {Math.round(totalCalories)}
          </p>
          <p className="text-xs text-muted-foreground mt-2">
            {Math.round((totalCalories / calorieGoal) * 100)}% of goal
          </p>
        </Card>
      </div>

      {/* Macros */}
      <Card className="p-6">
        <h2 className="font-semibold mb-6">{t(language, 'calories.macros')}</h2>
        <div className="grid grid-cols-3 gap-4">
          <div>
            <p className="text-2xl font-bold text-orange-500">
              {Math.round(totalProtein)}g
            </p>
            <p className="text-sm text-muted-foreground">
              {t(language, 'food.protein')}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {Math.round((totalProtein * 4) / totalCalories * 100 || 0)}% of calories
            </p>
          </div>
          <div>
            <p className="text-2xl font-bold text-blue-500">
              {Math.round(totalCarbs)}g
            </p>
            <p className="text-sm text-muted-foreground">
              {t(language, 'food.carbs')}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {Math.round((totalCarbs * 4) / totalCalories * 100 || 0)}% of calories
            </p>
          </div>
          <div>
            <p className="text-2xl font-bold text-yellow-500">
              {Math.round(totalFat)}g
            </p>
            <p className="text-sm text-muted-foreground">
              {t(language, 'food.fat')}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {Math.round((totalFat * 9) / totalCalories * 100 || 0)}% of calories
            </p>
          </div>
        </div>
      </Card>
    </main>
  );
}
