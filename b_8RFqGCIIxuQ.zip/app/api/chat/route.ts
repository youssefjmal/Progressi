import { streamText } from 'ai';
import { createClient } from '@/lib/supabase/server';

export async function POST(req: Request) {
  try {
    const { messages } = await req.json();
    const supabase = await createClient();

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return new Response('Unauthorized', { status: 401 });
    }

    // Get user profile for personalized context
    const { data: profile } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .single();

    const systemPrompt = `You are Coachini, a friendly and knowledgeable fitness coaching AI assistant. You help users with:
- Nutrition and meal planning advice
- Exercise and workout routines
- Fitness goal setting and tracking
- Healthy lifestyle tips
- Motivation and encouragement

User Profile:
${profile ? `- Weight: ${profile.current_weight}kg, Goal: ${profile.goal_weight}kg
- Age: ${profile.age}, Gender: ${profile.gender}
- Height: ${profile.height}cm, Activity Level: ${profile.activity_level}` : 'Profile not yet set'}

Provide personalized advice based on their profile. Be encouraging, practical, and evidence-based. Keep responses concise and actionable.`;

    const result = streamText({
      model: 'groq/mixtral-8x7b-32768',
      system: systemPrompt,
      messages: messages.map((msg: any) => ({
        role: msg.role,
        content: msg.content,
      })),
      maxTokens: 1024,
    });

    return result.toTextStreamResponse();
  } catch (error) {
    console.error('Chat error:', error);
    return new Response('Internal Server Error', { status: 500 });
  }
}
