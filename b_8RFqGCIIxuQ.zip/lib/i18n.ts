export type Language = 'en' | 'fr';

export const translations = {
  en: {
    // Navigation
    nav: {
      home: 'Home',
      food: 'Food',
      calories: 'Calories',
      chat: 'Coach',
      profile: 'Profile',
    },
    // Home/Dashboard
    dashboard: {
      title: 'Dashboard',
      welcome: 'Welcome to Coachini',
      subtitle: 'Your AI-powered fitness coach',
      goal: 'Goal Weight',
      current: 'Current Weight',
      startLogging: 'Start Logging Food',
    },
    // Food Logging
    food: {
      title: 'Log Food',
      search: 'Search foods',
      breakfast: 'Breakfast',
      lunch: 'Lunch',
      dinner: 'Dinner',
      snacks: 'Snacks',
      addFood: 'Add Food',
      quantity: 'Quantity',
      calories: 'Calories',
      protein: 'Protein',
      carbs: 'Carbs',
      fat: 'Fat',
    },
    // Calories
    calories: {
      title: 'Calories',
      todayCalories: "Today's Calories",
      remaining: 'Remaining',
      macros: 'Macros',
      goal: 'Daily Goal',
    },
    // Chatbot
    chat: {
      title: 'Fitness Coach',
      placeholder: 'Ask me anything about fitness...',
      send: 'Send',
      loading: 'Coaching...',
    },
    // Profile
    profile: {
      title: 'Profile',
      firstName: 'First Name',
      lastName: 'Last Name',
      age: 'Age',
      gender: 'Gender',
      height: 'Height (cm)',
      currentWeight: 'Current Weight (kg)',
      goalWeight: 'Goal Weight (kg)',
      activity: 'Activity Level',
      logout: 'Logout',
      save: 'Save',
    },
    // Auth
    auth: {
      email: 'Email',
      password: 'Password',
      login: 'Login',
      signup: 'Sign Up',
      already: 'Already have an account?',
      noAccount: "Don't have an account?",
      confirmEmail: 'Check your email to confirm your account',
    },
  },
  fr: {
    // Navigation
    nav: {
      home: 'Accueil',
      food: 'Aliments',
      calories: 'Calories',
      chat: 'Coach',
      profile: 'Profil',
    },
    // Home/Dashboard
    dashboard: {
      title: 'Tableau de bord',
      welcome: 'Bienvenue à Coachini',
      subtitle: 'Votre coach de fitness alimenté par l\'IA',
      goal: 'Poids objectif',
      current: 'Poids actuel',
      startLogging: 'Commencer à enregistrer les aliments',
    },
    // Food Logging
    food: {
      title: 'Enregistrer aliment',
      search: 'Rechercher des aliments',
      breakfast: 'Petit-déjeuner',
      lunch: 'Déjeuner',
      dinner: 'Dîner',
      snacks: 'Collations',
      addFood: 'Ajouter aliment',
      quantity: 'Quantité',
      calories: 'Calories',
      protein: 'Protéines',
      carbs: 'Glucides',
      fat: 'Lipides',
    },
    // Calories
    calories: {
      title: 'Calories',
      todayCalories: 'Calories d\'aujourd\'hui',
      remaining: 'Restant',
      macros: 'Macros',
      goal: 'Objectif quotidien',
    },
    // Chatbot
    chat: {
      title: 'Coach fitness',
      placeholder: 'Posez-moi une question sur la forme physique...',
      send: 'Envoyer',
      loading: 'Coaching...',
    },
    // Profile
    profile: {
      title: 'Profil',
      firstName: 'Prénom',
      lastName: 'Nom de famille',
      age: 'Âge',
      gender: 'Sexe',
      height: 'Taille (cm)',
      currentWeight: 'Poids actuel (kg)',
      goalWeight: 'Poids objectif (kg)',
      activity: 'Niveau d\'activité',
      logout: 'Déconnexion',
      save: 'Enregistrer',
    },
    // Auth
    auth: {
      email: 'Email',
      password: 'Mot de passe',
      login: 'Connexion',
      signup: 'Inscription',
      already: 'Vous avez déjà un compte?',
      noAccount: 'Vous n\'avez pas encore de compte?',
      confirmEmail: 'Vérifiez votre email pour confirmer votre compte',
    },
  },
};

export function getTranslation(lang: Language, path: string, defaultValue = ''): string {
  const keys = path.split('.');
  let current: any = translations[lang];

  for (const key of keys) {
    current = current?.[key];
    if (!current) return defaultValue;
  }

  return current || defaultValue;
}

export function t(lang: Language, key: string): string {
  return getTranslation(lang, key, key);
}
