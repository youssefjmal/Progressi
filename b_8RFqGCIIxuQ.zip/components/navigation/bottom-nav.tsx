'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, Apple, Flame, MessageCircle, User } from 'lucide-react';
import { useLanguage } from '@/hooks/use-language';
import { t } from '@/lib/i18n';

const navItems = [
  { href: '/dashboard', icon: Home, label: 'nav.home' },
  { href: '/food', icon: Apple, label: 'nav.food' },
  { href: '/calories', icon: Flame, label: 'nav.calories' },
  { href: '/chat', icon: MessageCircle, label: 'nav.chat' },
  { href: '/profile', icon: User, label: 'nav.profile' },
];

export function BottomNav() {
  const pathname = usePathname();
  const { language } = useLanguage();

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-background border-t border-border flex items-center justify-around h-20 md:hidden">
      {navItems.map(({ href, icon: Icon, label }) => {
        const isActive = pathname === href || pathname.startsWith(href + '/');
        return (
          <Link
            key={href}
            href={href}
            className={`flex flex-col items-center justify-center w-full h-full gap-1 transition-colors ${
              isActive
                ? 'text-primary'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <Icon size={24} />
            <span className="text-xs">{t(language, label)}</span>
          </Link>
        );
      })}
    </nav>
  );
}
