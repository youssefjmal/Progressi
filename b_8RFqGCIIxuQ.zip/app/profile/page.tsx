'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { useLanguage } from '@/hooks/use-language';
import { t } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import type { Language } from '@/lib/i18n';

interface Profile {
  id: string;
  first_name: string | null;
  last_name: string | null;
  age: number | null;
  gender: string | null;
  height: number | null;
  current_weight: number | null;
  goal_weight: number | null;
  activity_level: string | null;
  language: Language;
}

export default function ProfilePage() {
  const router = useRouter();
  const { language, setLanguage } = useLanguage();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const supabase = createClient();

  useEffect(() => {
    const loadProfile = async () => {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser();

        if (!user) {
          router.push('/auth/login');
          return;
        }

        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();

        if (error) throw error;
        setProfile(data);
      } catch (err) {
        console.error('Error loading profile:', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadProfile();
  }, [supabase, router]);

  const handleSave = async () => {
    if (!profile) return;

    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          first_name: profile.first_name,
          last_name: profile.last_name,
          age: profile.age,
          gender: profile.gender,
          height: profile.height,
          current_weight: profile.current_weight,
          goal_weight: profile.goal_weight,
          activity_level: profile.activity_level,
          language: profile.language,
        })
        .eq('id', profile.id);

      if (error) throw error;
      alert('Profile saved!');
    } catch (err) {
      console.error('Error saving profile:', err);
      alert('Failed to save profile');
    } finally {
      setIsSaving(false);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    router.push('/');
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <main className="max-w-2xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">{t(language, 'profile.title')}</h1>

      {profile && (
        <form
          className="space-y-6"
          onSubmit={(e) => {
            e.preventDefault();
            handleSave();
          }}
        >
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">
                {t(language, 'profile.firstName')}
              </label>
              <Input
                value={profile.first_name || ''}
                onChange={(e) =>
                  setProfile({ ...profile, first_name: e.target.value })
                }
                placeholder="John"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">
                {t(language, 'profile.lastName')}
              </label>
              <Input
                value={profile.last_name || ''}
                onChange={(e) =>
                  setProfile({ ...profile, last_name: e.target.value })
                }
                placeholder="Doe"
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">
                {t(language, 'profile.age')}
              </label>
              <Input
                type="number"
                value={profile.age || ''}
                onChange={(e) =>
                  setProfile({
                    ...profile,
                    age: e.target.value ? parseInt(e.target.value) : null,
                  })
                }
                placeholder="30"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">
                {t(language, 'profile.gender')}
              </label>
              <Input
                value={profile.gender || ''}
                onChange={(e) =>
                  setProfile({ ...profile, gender: e.target.value })
                }
                placeholder="Male / Female"
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">
                {t(language, 'profile.height')}
              </label>
              <Input
                type="number"
                value={profile.height || ''}
                onChange={(e) =>
                  setProfile({
                    ...profile,
                    height: e.target.value ? parseFloat(e.target.value) : null,
                  })
                }
                placeholder="180"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">
                {t(language, 'profile.currentWeight')}
              </label>
              <Input
                type="number"
                step="0.1"
                value={profile.current_weight || ''}
                onChange={(e) =>
                  setProfile({
                    ...profile,
                    current_weight: e.target.value
                      ? parseFloat(e.target.value)
                      : null,
                  })
                }
                placeholder="75"
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">
                {t(language, 'profile.goalWeight')}
              </label>
              <Input
                type="number"
                step="0.1"
                value={profile.goal_weight || ''}
                onChange={(e) =>
                  setProfile({
                    ...profile,
                    goal_weight: e.target.value
                      ? parseFloat(e.target.value)
                      : null,
                  })
                }
                placeholder="70"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">
                {t(language, 'profile.activity')}
              </label>
              <Input
                value={profile.activity_level || ''}
                onChange={(e) =>
                  setProfile({ ...profile, activity_level: e.target.value })
                }
                placeholder="Moderate"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Language</label>
            <select
              value={profile.language}
              onChange={(e) => {
                const newLang = e.target.value as Language;
                setProfile({ ...profile, language: newLang });
                setLanguage(newLang);
              }}
              className="w-full px-3 py-2 border border-input rounded-md"
            >
              <option value="en">English</option>
              <option value="fr">Français</option>
            </select>
          </div>

          <div className="flex gap-4 pt-6">
            <Button type="submit" disabled={isSaving} className="flex-1">
              {t(language, 'profile.save')}
            </Button>
            <Button
              type="button"
              variant="destructive"
              onClick={handleLogout}
              className="flex-1"
            >
              {t(language, 'profile.logout')}
            </Button>
          </div>
        </form>
      )}
    </main>
  );
}
