import React from 'react';

interface WatermelonChartProps {
  consumed: number;
  goal: number;
  className?: string;
}

export function WatermelonChart({
  consumed,
  goal,
  className = '',
}: WatermelonChartProps) {
  const percentage = Math.min((consumed / goal) * 100, 100);

  return (
    <div className={`flex flex-col items-center justify-center ${className}`}>
      <svg
        viewBox="0 0 200 200"
        className="w-32 h-32 md:w-40 md:h-40"
        style={{ maxWidth: '100%' }}
      >
        {/* Watermelon outline */}
        <circle
          cx="100"
          cy="100"
          r="95"
          fill="#22c55e"
          stroke="#16a34a"
          strokeWidth="2"
        />

        {/* Watermelon flesh - filled portion */}
        <defs>
          <clipPath id="watermelonClip">
            <circle cx="100" cy="100" r="85" />
          </clipPath>
        </defs>

        {/* Red flesh filled from bottom */}
        <g clipPath="url(#watermelonClip)">
          <rect
            x="15"
            y={100 + (85 - (170 * percentage) / 100)}
            width="170"
            height={(170 * percentage) / 100}
            fill="#ef4444"
          />
        </g>

        {/* Seeds */}
        {[...Array(Math.floor(percentage / 10) + 3)].map((_, i) => {
          const angle = (i * Math.PI * 2) / 6;
          const radius = 40;
          const x = 100 + Math.cos(angle) * radius;
          const y = 100 + Math.sin(angle) * radius;
          return (
            <circle
              key={i}
              cx={x}
              cy={y}
              r="3"
              fill="#000"
              opacity="0.7"
            />
          );
        })}

        {/* Watermelon rind pattern */}
        <circle
          cx="100"
          cy="100"
          r="95"
          fill="none"
          stroke="#15803d"
          strokeWidth="1"
          strokeDasharray="5,5"
          opacity="0.3"
        />
      </svg>

      <div className="mt-6 text-center">
        <p className="text-3xl font-bold">{Math.round(percentage)}%</p>
        <p className="text-sm text-muted-foreground">
          {Math.round(consumed)} / {Math.round(goal)} calories
        </p>
      </div>
    </div>
  );
}
