'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { useLanguage } from '@/hooks/use-language';
import { t } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Search, Plus, Trash2 } from 'lucide-react';

interface Food {
  id: string;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  serving_size: number;
  serving_unit: string;
}

interface LoggedFood {
  id: string;
  food_id: string;
  meal_type: string;
  quantity: number;
  unit: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  food_name: string;
}

const MEAL_TYPES = ['breakfast', 'lunch', 'dinner', 'snacks'];

export default function FoodPage() {
  const router = useRouter();
  const { language } = useLanguage();
  const [foods, setFoods] = useState<Food[]>([]);
  const [loggedFoods, setLoggedFoods] = useState<LoggedFood[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMeal, setSelectedMeal] = useState('breakfast');
  const [selectedFood, setSelectedFood] = useState<Food | null>(null);
  const [quantity, setQuantity] = useState('100');
  const [isLoading, setIsLoading] = useState(true);
  const supabase = createClient();

  useEffect(() => {
    const loadData = async () => {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser();

        if (!user) {
          router.push('/auth/login');
          return;
        }

        // Load foods
        const { data: foodsData, error: foodsError } = await supabase
          .from('foods')
          .select('*')
          .order('name');

        if (foodsError) throw foodsError;
        setFoods(foodsData || []);

        // Load logged foods for today
        const today = new Date().toISOString().split('T')[0];
        const { data: logsData, error: logsError } = await supabase
          .from('food_logs')
          .select('*')
          .eq('user_id', user.id)
          .gte('logged_at', `${today}T00:00:00`)
          .lte('logged_at', `${today}T23:59:59`)
          .order('logged_at', { ascending: false });

        if (logsError) throw logsError;

        // Enrich logged foods with food names
        const enriched = (logsData || []).map((log: any) => {
          const food = foodsData?.find((f) => f.id === log.food_id);
          return { ...log, food_name: food?.name || 'Unknown' };
        });

        setLoggedFoods(enriched);
      } catch (err) {
        console.error('Error loading data:', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, [supabase, router]);

  const handleAddFood = async () => {
    if (!selectedFood) return;

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) return;

      const quantityNum = parseFloat(quantity) || 100;
      const multiplier = quantityNum / selectedFood.serving_size;

      const { error } = await supabase.from('food_logs').insert({
        user_id: user.id,
        food_id: selectedFood.id,
        meal_type: selectedMeal,
        quantity: quantityNum,
        unit: selectedFood.serving_unit,
        calories: Math.round(selectedFood.calories * multiplier * 10) / 10,
        protein: Math.round(selectedFood.protein * multiplier * 10) / 10,
        carbs: Math.round(selectedFood.carbs * multiplier * 10) / 10,
        fat: Math.round(selectedFood.fat * multiplier * 10) / 10,
      });

      if (error) throw error;

      // Reload logged foods
      const today = new Date().toISOString().split('T')[0];
      const { data: logsData } = await supabase
        .from('food_logs')
        .select('*')
        .eq('user_id', user.id)
        .gte('logged_at', `${today}T00:00:00`)
        .lte('logged_at', `${today}T23:59:59`)
        .order('logged_at', { ascending: false });

      const enriched = (logsData || []).map((log: any) => {
        const food = foods.find((f) => f.id === log.food_id);
        return { ...log, food_name: food?.name || 'Unknown' };
      });

      setLoggedFoods(enriched);
      setSelectedFood(null);
      setQuantity('100');
    } catch (err) {
      console.error('Error adding food:', err);
      alert('Failed to add food');
    }
  };

  const handleDeleteFood = async (id: string) => {
    try {
      const { error } = await supabase
        .from('food_logs')
        .delete()
        .eq('id', id);

      if (error) throw error;

      setLoggedFoods(loggedFoods.filter((f) => f.id !== id));
    } catch (err) {
      console.error('Error deleting food:', err);
      alert('Failed to delete food');
    }
  };

  const filteredFoods = foods.filter((f) =>
    f.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalCalories = loggedFoods.reduce((sum, f) => sum + f.calories, 0);
  const totalProtein = loggedFoods.reduce((sum, f) => sum + f.protein, 0);
  const totalCarbs = loggedFoods.reduce((sum, f) => sum + f.carbs, 0);
  const totalFat = loggedFoods.reduce((sum, f) => sum + f.fat, 0);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <main className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">{t(language, 'food.title')}</h1>

      {/* Summary Card */}
      <Card className="p-6 mb-8">
        <p className="text-sm text-muted-foreground mb-2">Today&apos;s Totals</p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <p className="text-2xl font-bold">{Math.round(totalCalories)}</p>
            <p className="text-xs text-muted-foreground">Calories</p>
          </div>
          <div>
            <p className="text-2xl font-bold">{Math.round(totalProtein)}g</p>
            <p className="text-xs text-muted-foreground">Protein</p>
          </div>
          <div>
            <p className="text-2xl font-bold">{Math.round(totalCarbs)}g</p>
            <p className="text-xs text-muted-foreground">Carbs</p>
          </div>
          <div>
            <p className="text-2xl font-bold">{Math.round(totalFat)}g</p>
            <p className="text-xs text-muted-foreground">Fat</p>
          </div>
        </div>
      </Card>

      {/* Add Food Section */}
      <Card className="p-6 mb-8">
        <h2 className="font-semibold mb-4">{t(language, 'food.addFood')}</h2>

        {/* Search */}
        <div className="mb-4">
          <div className="flex gap-2 mb-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder={t(language, 'food.search')}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {/* Food List */}
          {searchQuery && (
            <div className="space-y-2 max-h-64 overflow-y-auto mb-4">
              {filteredFoods.slice(0, 10).map((food) => (
                <button
                  key={food.id}
                  onClick={() => setSelectedFood(food)}
                  className={`w-full p-3 text-left rounded-md border transition-colors ${
                    selectedFood?.id === food.id
                      ? 'bg-primary text-primary-foreground border-primary'
                      : 'border-border hover:bg-muted'
                  }`}
                >
                  <p className="font-medium">{food.name}</p>
                  <p className="text-sm opacity-75">
                    {food.calories} cal / {food.serving_size}{food.serving_unit}
                  </p>
                </button>
              ))}
            </div>
          )}
        </div>

        {selectedFood && (
          <>
            {/* Meal Type */}
            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">Meal Type</label>
              <select
                value={selectedMeal}
                onChange={(e) => setSelectedMeal(e.target.value)}
                className="w-full px-3 py-2 border border-input rounded-md"
              >
                {MEAL_TYPES.map((m) => (
                  <option key={m} value={m}>
                    {t(language, `food.${m}`)}
                  </option>
                ))}
              </select>
            </div>

            {/* Quantity */}
            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">
                {t(language, 'food.quantity')} ({selectedFood.serving_unit})
              </label>
              <Input
                type="number"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                placeholder="100"
              />
            </div>

            {/* Add Button */}
            <Button onClick={handleAddFood} className="w-full">
              <Plus className="w-4 h-4 mr-2" />
              Add Food
            </Button>
          </>
        )}
      </Card>

      {/* Logged Foods */}
      <div>
        <h2 className="font-semibold mb-4">Today&apos;s Log</h2>
        <div className="space-y-4">
          {loggedFoods.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">
              No foods logged yet
            </p>
          ) : (
            loggedFoods.map((log) => (
              <Card key={log.id} className="p-4 flex justify-between items-start">
                <div className="flex-1">
                  <p className="font-medium">{log.food_name}</p>
                  <p className="text-sm text-muted-foreground capitalize">
                    {t(language, `food.${log.meal_type}`)}
                  </p>
                  <p className="text-sm mt-2">
                    {log.calories} cal • P: {Math.round(log.protein)}g • C:{' '}
                    {Math.round(log.carbs)}g • F: {Math.round(log.fat)}g
                  </p>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleDeleteFood(log.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </Card>
            ))
          )}
        </div>
      </div>
    </main>
  );
}
