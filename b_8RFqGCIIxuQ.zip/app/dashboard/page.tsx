'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { useLanguage } from '@/hooks/use-language';
import { t } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface Profile {
  first_name: string;
  last_name: string;
  current_weight: number;
  goal_weight: number;
}

export default function DashboardPage() {
  const router = useRouter();
  const { language } = useLanguage();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const supabase = createClient();

  useEffect(() => {
    const loadProfile = async () => {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser();

        if (!user) {
          router.push('/auth/login');
          return;
        }

        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();

        if (error) throw error;
        setProfile(data);
      } catch (err) {
        console.error('Error loading profile:', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadProfile();
  }, [supabase, router]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <main className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-2">{t(language, 'dashboard.welcome')}</h1>
      <p className="text-muted-foreground mb-8">{t(language, 'dashboard.subtitle')}</p>

      {profile && (
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card className="p-6">
            <p className="text-muted-foreground text-sm mb-2">{t(language, 'dashboard.current')}</p>
            <p className="text-3xl font-bold">{profile.current_weight} kg</p>
          </Card>
          <Card className="p-6">
            <p className="text-muted-foreground text-sm mb-2">{t(language, 'dashboard.goal')}</p>
            <p className="text-3xl font-bold">{profile.goal_weight} kg</p>
          </Card>
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-4">
        <Button
          size="lg"
          onClick={() => router.push('/food')}
          className="w-full"
        >
          {t(language, 'dashboard.startLogging')}
        </Button>
        <Button
          size="lg"
          variant="outline"
          onClick={() => router.push('/chat')}
          className="w-full"
        >
          {t(language, 'chat.title')}
        </Button>
      </div>
    </main>
  );
}
